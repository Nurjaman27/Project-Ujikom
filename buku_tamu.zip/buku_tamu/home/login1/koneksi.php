<?php
$konek = new mysqli("localhost","root","","login1") or die ("error");



?>