<?php
$konek = new  mysqli ("localhost","root","","bukutamu") or die ("error");

?>